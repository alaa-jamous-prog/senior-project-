import NewsFeed from "../../../components/news-feed"

export default function NewsFeedPage() {  
  return (
    <div className="min-h-screen bg-[#E5EAE7]">
      <NewsFeed />
    </div>
  )
}
